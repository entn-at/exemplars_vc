pytest $(dirname $0)/tests --benchmark-autosave
