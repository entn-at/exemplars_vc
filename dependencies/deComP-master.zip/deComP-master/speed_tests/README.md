# How to make a speed test

## Requirements

1. Install pytest
2. Install pytest-benchmark
3. (optional) Install cuda and cupy

## How to run
3. ./speed_test.sh
