class ShapeMismatchError(ValueError):
    pass


class DimInvalidError(ValueError):
    pass


class DtypeMismatchError(ValueError):
    pass
