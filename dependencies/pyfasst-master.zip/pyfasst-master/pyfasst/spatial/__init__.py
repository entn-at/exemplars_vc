'''spatial filtering scripts and functions
'''
