from distutils.core import setup

setup(
    name="SeparateLeadStereo",
    version='0.3',
    packages=['SIMM', 'tracking'],
    license='',
    )
