pyfasst
=======

Python implementation of the Flexible Audio Source Separation Toolbox (FASST)

See also the documentation in ``doc``. To build the doc::

    cd doc
    make html

The documentation will then be built in ``doc/build/html/``. Open the ``index.html`` file.
