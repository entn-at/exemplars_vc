=====================
Spatial Signal Models 
=====================

draws directivity diagrams for ULA assumption

Contents
========

.. automodule:: pyfasst.spatial.dirdiag
    :members:

.. automodule:: pyfasst.spatial.steering_vectors
    :members:

