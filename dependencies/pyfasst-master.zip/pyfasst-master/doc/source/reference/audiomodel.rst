audioModel
==========

.. automodule:: pyfasst.audioModel
    :members:

