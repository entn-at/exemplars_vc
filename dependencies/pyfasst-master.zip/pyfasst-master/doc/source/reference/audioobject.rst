audioObject
===========

.. automodule:: pyfasst.audioObject
    :members:

