.. pyFASST documentation master file, created by
   sphinx-quickstart on Wed Jan 30 11:13:42 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyFASST's documentation!
===================================

This documentation gives some `example uses <description.html#using-the-python-package>`_ as well as some `descriptions <description.html#algorithms>`_ and `references <description.html#references>`_. 

Furthermore, the documentation for each of the modules is given in `these reference pages <reference.html>`_. 

Contents:
=========

.. toctree::
   :maxdepth: 2
   
   description
   reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
